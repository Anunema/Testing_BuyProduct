package Pages;

import locator.Locator;

public class Coupon {
	
	public static void Coupons(){
		Locator.Coupon();
	}
	public static void Apply() {
		Locator.Coupon_apply();
	}
}
