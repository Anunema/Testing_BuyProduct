package Pages;


import BrowserEbay.BrowserEbay;
import locator.Locator;

public class Search extends BrowserEbay{
//	public static void Driver() {
//		Locator.setDriver1();
//	}
//	public static void Login() {
//		
//		Locator.clickLogin();
//		Locator.enterValideEmail();
//		Locator.enterValidePassword();
//		Locator.SignIn();
//		Locator.Checklogin();
//	}
//	
	
	public static void Searchs() {
		
		Locator.Search();
		
}
}
