package Pages;

import locator.Locator;

public class Donate {
	
	
	public static void Donates() {
		Locator.Donate();
	}
	//public static void confirm() {
		//Locator.buy_Button();
	//}
}
