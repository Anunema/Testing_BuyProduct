package Pages;

import locator.Locator;

public class BillingAddress {
	
  public static void Billing1() {
	  Locator.Billing_details();
  }
  public static void Billing2() {
	  Locator.Billing_manual_Address();
  }
  public static void Billing3() {
	  Locator.Billing_Number();
	
	}
  public static void Checkout() {
	  Locator.CheckoutButton();
  }
}
