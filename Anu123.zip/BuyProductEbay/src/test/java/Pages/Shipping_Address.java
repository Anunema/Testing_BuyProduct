package Pages;

//import locator.Locator;

public class Shipping_Address {
	
	//public static void Shipping() {
		//Locator.Shipping();
	//}
}
