package Pages;

import locator.Locator;

public class Review {
	
public static void Reviews() {
	Locator.Review();
}
}
